<?php include 'header.php'; ?>

<section class="alpha">
  <h1><a href=""><?=$s['title'];?></a></h1>
  <?=$txt['content.txt'];?>
</section>